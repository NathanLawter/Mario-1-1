﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GoombaController : MonoBehaviour
{
    public float speed;
    public Transform[] points;
    private int point;

    // Use this for initialization
    void Start()
    {
        point = Random.Range(0, points.Length);
    }

    // Update is called once per frame
    void Update()
    {
        transform.position = Vector2.MoveTowards(transform.position, points[point].position, speed * Time.deltaTime);
        if (Vector2.Distance(transform.position, points[point].position) < 0.2f)
            point = Random.Range(0, points.Length);
        {
            
        }
        

        
    }
}
