﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BlockOfCoins : MonoBehaviour
{
    public GameObject coin;

    void OnCollisionEnter(Collision c)
    {   
        if (c.collider.tag == "Player")
            Instantiate(coin, transform.position, transform.rotation);
    }
}